#request and response validation with Pydantic

""" from fastapi import FastAPI,HTTPException
from pydantic  import BaseModel, Field


app = FastAPI()

# rqst model
class Item(BaseModel):
    name : str = Field(..., max_length=100, description="name of the item")
    price : float = Field(..., ge=2, description="price of the item")
    is_offer : bool = Field(default=False, description="offer item")

#response model
class Response(BaseModel):
    success : bool
    data : Item
    message : str

@app.post("/items", response_model= Response)
def create_item(item: Item):
    if item.price > 1000:
        raise HTTPException(status_code=400, details= " price too high")
    return Response(success=True, data=item, message="item created successfully")

@app.get("/items/sample", response_model=Item)
def sample_item():
    sample_item = Item(name="sample", price=100.20, is_offer=True) """

# JWT
"""from fastapi import FastAPI,Depends, HTTPException,status
from fastapi.security import OAuth2PasswordBearer 
from pydantic import BaseModel
import jwt
from datetime import datetime, timedelta

app = FastAPI()

# Secret key to encode and decode JWT tokens
SECRET_KEY = "keyy"
ALGORITHM = "hs26"
TOKEN_EXPIRE_MIN = 30

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login") #specifies login endpoint for token retrieval

class userlogin(BaseModel):
    username : str
    password : str


#creating a databasse
fake_db = {
    "user1": {
        "username" : "jeevva",
        "password" : "password1"
    }
}

# fn to authenticate user and generate JWT token
def authenticate_user(username : str, password: str):
    user = fake_db.get(username)
    if not user or user["password"] != password:
        raise HTTPException(status_code = status.HTTP_401_UNAUTHORIZED, detail="invalid credential")
    return user

#fn to create access token

def create_access_token(data: dict, expire_delta : timedelta = timedelta(minutes=TOKEN_EXPIRE_MIN)):
    to_encode = data.copy()
    expire = datetime.utcnow()+ expire_delta  #current time+ expiring tym
    to_encode.update({"exp" : expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)   #secret key = is used to sign the token...#algorithm = specifies the hashing algorithm used for signing the token.
    return encoded_jwt

# Dependency for Current User
def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        return username
    except jwt.PyJWTError:
        raise credentials_exception
    
# route for user login
@app.post("/login")
def login(user: userlogin):
    user_data = authenticate_user(user.username, user.password)
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

#protected route which requires valid jwt tokens
@app.get("/protected")
def read_protected(current_user: str = Depends(get_current_user)):
    return {"message": f"Hello {current_user}, this is a protected route!"}"""




# crud operation main  file

from sqlalchemy.orm import Session
from fastapi import HTTPException, Depends
from models import models, schemas, crud
from .database import get_db
from fastapi import FastAPI

app = FastAPI()

# Delete a student ---by ID
def delete_student(db: Session, student_id: int):
    db_student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not db_student:
        raise HTTPException(status_code=404, detail="Student not found")
    db.delete(db_student)
    db.commit()
    return db_student

# Create student
@app.post("/students/", response_model=schemas.Student)
def create_student(student: schemas.StudentCreate, db: Session = Depends(get_db)):
    return crud.create_student(db=db, student=student)

# Get all students
@app.get("/students/", response_model=list[schemas.Student])
def read_students(db: Session = Depends(get_db)):
    students = crud.get_students(db=db)
    return students

# Get a student ---> by ID
@app.get("/students/{student_id}", response_model=schemas.Student)
def read_student(student_id: int, db: Session = Depends(get_db)):
    db_student = crud.get_student(db=db, student_id=student_id)
    if not db_student:
        raise HTTPException(status_code=404, detail="Student not found")
    return db_student


@app.put("/students/{student_id}", response_model=schemas.Student)
def edit_student_status(student_id: int, student: schemas.StudentUpdate, db: Session = Depends(get_db)):
    return crud.update_student(db=db, student_id=student_id, student=student) 
